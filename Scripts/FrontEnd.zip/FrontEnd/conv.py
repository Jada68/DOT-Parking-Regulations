import geopandas as gp


df = gp.read_file("lines.geojson")
df.to_crs(4326).to_file("lines_4326.geojson")
